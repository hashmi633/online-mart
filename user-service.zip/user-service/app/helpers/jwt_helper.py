from datetime import datetime, timedelta
from fastapi.security import OAuth2PasswordBearer
from typing import Annotated
from jose import jwt, JWTError 


ALGORITHM = "HS256"
SECRET_KEY = "My Secure Key"
ACCESS_TOKEN_EXPIRATION_TIME = 2

oath2_scheme = OAuth2PasswordBearer(tokenUrl="/admin/login")

def create_access_token(data: dict):
    to_encode = data.copy()
    expiration_time = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRATION_TIME)
    to_encode.update({"exp": expiration_time})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt



