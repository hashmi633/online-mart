from sqlmodel import Session, select
from app.models.user_models import User
from app.db.db_connector import DB_SESSION
from fastapi import HTTPException


def admin_authentication(user_id: int, session: DB_SESSION):
    user = session.exec(select(User).where(User.user_id == user_id)).first()
    
    if not user or not user.is_admin:
        raise HTTPException(
            status_code=404, detail="Admin access required."
        )
    return user



