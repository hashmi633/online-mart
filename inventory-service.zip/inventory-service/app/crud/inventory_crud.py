from app.models.inventory_models import Category
from sqlmodel import Session, select
from fastapi import HTTPException, Depends
from typing import Annotated
from app.jwt_helper import verify_token, oath2_scheme

def add_to_category(category_data:Category,session: Session):
    existing_category = session.exec(select(Category).where(category_data.category_id==Category.category_id)).first()
    session.add(category_data)
    session.commit()
    session.refresh(category_data)
    return category_data

def get_current_admin(token: Annotated[str, Depends(oath2_scheme)]):
    return get_current_user_by_role(token, role="admin")

def get_current_user_by_role(token: str, role : str):
    try:
        payload = verify_token(token)   
    except HTTPException as e:
        if e.detail == "Token has expired":
            raise HTTPException(
                status_code=401, 
                detail="Token has expired, please log in again."
            )
        else:
            raise e
    if payload.get("role") != role:
        raise HTTPException(
            status_code=403, 
            detail=f"{role.capitalize()} access required"
        )
    return payload