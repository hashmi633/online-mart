from fastapi import APIRouter, Depends, HTTPException
from app.models.inventory_models import Category,Warehouse,InventoryItem
from app.db.db_connector import DB_SESSION, get_session
from app.crud.inventory_crud import add_to_category, get_current_admin
from typing import Annotated
from sqlmodel import Session
from app.jwt_helper import oath2_scheme
from app.shared_helper import validate_token

router = APIRouter()

@router.get('/')
def welcome():
    return{"Hello":"Welcome to Inventory Service"}

@router.post('/add_category')
def add_category(category_details: Category, session:DB_SESSION, token:dict = Depends(oath2_scheme)):
    print(f"Token receive from User Service:  {token}")
    # user_data = validate_token(token)
    # user_role = user_data.get("role")
    # if user_role != "admin":
    #     raise HTTPException(status_code=403, detail="Only admins can add categories.")
    # added_category = add_to_category(category_details,session)
    return {"token": token, "added category": "added_category"}